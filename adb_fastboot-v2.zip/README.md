# 向系统添加 adb 和 fastboot
将 adb 和 fastboot 置入到 `/system/xbin`

## 更新日志
v2

    - 更新到 Template v4
v1.1

    - 修复权限
v1

    - 第一版
